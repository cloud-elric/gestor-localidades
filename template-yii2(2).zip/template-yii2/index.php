<?php
header("Location: web");
die();
