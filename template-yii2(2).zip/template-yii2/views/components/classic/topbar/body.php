<!-- Page -->
<div class="page">
    <div class="page-content">
      <h2><?=$this->title?></h2>
      <?=$content?>
    </div>
  </div>
  <!-- End Page -->